package clasificacionweka;

import weka.classifiers.trees.RandomForest;
import weka.core.Instance;
import weka.core.Instances;
import weka.core.converters.ConverterUtils.DataSource;
import weka.classifiers.Evaluation;
import java.util.ArrayList;
import java.util.Random;

public class ClasificacionRandomForest {
    private RandomForest clasificador;
    private Instances datos;
    private StringBuilder resultadosEntrenamiento;
    private double precision;
    private double error;

    public void cargarDatos(String rutaArchivo) {
        try {
            DataSource fuente = new DataSource(rutaArchivo);
            datos = fuente.getDataSet();

            if (datos.classIndex() == -1) {
                datos.setClassIndex(datos.numAttributes() - 1);
            }

            resultadosEntrenamiento = new StringBuilder();
            resultadosEntrenamiento.append("=== Información del Dataset ===\n");
            resultadosEntrenamiento.append("Nombre del dataset: " + datos.relationName() + "\n");
            resultadosEntrenamiento.append("Número de instancias: " + datos.numInstances() + "\n");
            resultadosEntrenamiento.append("Número de atributos: " + datos.numAttributes() + "\n\n");

            resultadosEntrenamiento.append("=== Detalle de Atributos ===\n");
            for (int i = 0; i < datos.numAttributes(); i++) {
                resultadosEntrenamiento.append((i+1) + ". " + datos.attribute(i).name() +
                        (i == datos.classIndex() ? " (clase)" : "") + "\n");
                if (datos.attribute(i).isNominal()) {
                    resultadosEntrenamiento.append("   Valores: ");
                    for (int j = 0; j < datos.attribute(i).numValues(); j++) {
                        resultadosEntrenamiento.append(datos.attribute(i).value(j));
                        if (j < datos.attribute(i).numValues() - 1) {
                            resultadosEntrenamiento.append(", ");
                        }
                    }
                    resultadosEntrenamiento.append("\n");
                }
            }
        } catch (Exception e) {
            throw new RuntimeException("Error al cargar datos: " + e.getMessage());
        }
    }

    public void entrenarModelo() {
        try {
            clasificador = new RandomForest();

            String[] opciones = new String[]{
                    "-I", "100",  // número de árboles
                    "-K", "0",    // número de atributos
                    "-S", "1"     // semilla para reproducibilidad
            };
            clasificador.setOptions(opciones);

            long tiempoInicio = System.currentTimeMillis();
            clasificador.buildClassifier(datos);
            long tiempoFin = System.currentTimeMillis();

            Evaluation eval = new Evaluation(datos);
            eval.crossValidateModel(clasificador, datos, 10, new Random(1));

            precision = eval.pctCorrect();
            error = eval.pctIncorrect();

            resultadosEntrenamiento.append("\n=== Resultados del Entrenamiento ===\n");
            resultadosEntrenamiento.append("Tiempo: " + (tiempoFin - tiempoInicio) + "ms\n");
            resultadosEntrenamiento.append("Precisión: " + String.format("%.2f%%\n", precision));
            resultadosEntrenamiento.append("Error: " + String.format("%.2f%%\n", error));
            resultadosEntrenamiento.append("\nMatriz de Confusión:\n");
            resultadosEntrenamiento.append(eval.toMatrixString());

        } catch (Exception e) {
            throw new RuntimeException("Error al entrenar modelo: " + e.getMessage());
        }
    }

    public String clasificarInstancia(ArrayList<String> valores) {
        try {
            if (clasificador == null) {
                return "Error: El modelo no ha sido entrenado";
            }

            Instance instancia = new weka.core.DenseInstance(datos.numAttributes());
            instancia.setDataset(datos);

            for (int i = 0; i < valores.size() && i < datos.numAttributes(); i++) {
                if (datos.attribute(i).isNumeric()) {
                    try {
                        double valor = Double.parseDouble(valores.get(i));
                        instancia.setValue(i, valor);
                    } catch (NumberFormatException e) {
                        return "Error: El valor '" + valores.get(i) + "' debe ser numérico";
                    }
                } else {
                    instancia.setValue(datos.attribute(i), valores.get(i));
                }
            }

            double resultado = clasificador.classifyInstance(instancia);
            String clasificacion = datos.classAttribute().value((int) resultado);

            double[] probabilidades = clasificador.distributionForInstance(instancia);
            double confianza = probabilidades[(int) resultado] * 100;

            if (clasificacion.equalsIgnoreCase("good")) {
                return String.format("CRÉDITO APROBADO\nSe recomienda aprobar este crédito.\nNivel de confianza: %.2f%%", confianza);
            } else {
                return String.format("CRÉDITO NO APROBADO\nNo se recomienda aprobar este crédito.\nNivel de confianza: %.2f%%", confianza);
            }

        } catch (Exception e) {
            return "Error en la clasificación: " + e.getMessage();
        }
    }

    public String obtenerResultadosEntrenamiento() {
        return resultadosEntrenamiento.toString();
    }

    public double getPrecision() {
        return precision;
    }

    public double getError() {
        return error;
    }

    public Instances getDatos() {
        return datos;
    }

    public String[] getValoresPermitidos(String nombreAtributo) {
        for (int i = 0; i < datos.numAttributes(); i++) {
            if (datos.attribute(i).name().equals(nombreAtributo)) {
                String[] valores = new String[datos.attribute(i).numValues()];
                for (int j = 0; j < datos.attribute(i).numValues(); j++) {
                    valores[j] = datos.attribute(i).value(j);
                }
                return valores;
            }
        }
        return new String[0];
    }

    public void imprimirNombresAtributos() {
        System.out.println("Nombres de atributos en el dataset:");
        for (int i = 0; i < datos.numAttributes(); i++) {
            System.out.println(i + ": " + datos.attribute(i).name());
        }
    }
}